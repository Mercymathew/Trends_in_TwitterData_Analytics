# twitter-data-analysis-
Data analysis of Twitter big data using Python


STEPS FOR BIG DATA ANALYTICS IN TWITTER

Abstract

Perform real-time data analysis of Twitter data using a pipeline built on Google compute engine , Kubernetes, Redis and Big Query. Identifying general patterns and trends in data. Google Big query is a data analysis tool, which can crunch terabytes of data on demand in seconds using expensive in –memory technology. Extensively inside of google for analyzing large data sets and log file for year and it also available externally.


Requirements- 

PYTHON 2.7-PYTHON 3.5(latest)
Cloud based application - Wakari IO , IBM Bluemix , AWS
Database - Redis


Run the code in cloud based platform , in the form of notebook.

import required packages , modules,
create the twitter id- Goto-> application/product development get the consumer key and consumer secret key and give to the code ,
that is replace my KEY and ID ,
consumerKey = 'iPIcJAmPTQYiEZ3FF01iuVcvI'
consumerSecret = '8P39msYkvZHdP4wxbhtl7GhFvUfAlJVSMPMTQJRAQr2ESDUbxR'

Run the code , get the ouput , store the information using REDIS( Cloud based database) , sqlite3 can also used in python.
Analyze the output , store the Data , access the data , manipulate the data using Big query
